using UnityEngine;

public class Player_FloorCheck : MonoBehaviour
{
    // Private Variables
    private bool _floored = false;
    private int _collisionCount = 0;

    // Called when something collides with this object
    private void OnTriggerEnter2D(Collider2D collision)
    {
        // Add one to the number of current collisions
        _collisionCount++;

        // Check if we are now on the floor
        AmFloored();
    }
    // Called when something stops colliding with this object
    private void OnTriggerExit2D(Collider2D collision)
    {
        // Subtract one to the number of current collisions
        _collisionCount--;

        // Check if we are still on the floor
        AmFloored();
    }

    // Figures out whether we are standing on anything
    private void AmFloored()
    {
        // Are there any things colliding with this object?
        if (_collisionCount > 0)
        {
            // Then we must be floored
            _floored = true;
        }
        // Otherwise
        else
        {
            // We cannot be on the floor anymore
            _floored = false;
        }
    }

    // Fields
    public bool Floored { get { return _floored; } }
}
