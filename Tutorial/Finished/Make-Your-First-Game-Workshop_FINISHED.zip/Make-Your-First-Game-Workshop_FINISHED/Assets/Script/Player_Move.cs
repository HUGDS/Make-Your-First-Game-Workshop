using UnityEngine;
using UnityEngine.InputSystem;

public class Player_Move : MonoBehaviour
{
    // Editor Variables
    [SerializeField]
    private Rigidbody2D _rigidBody;
    [SerializeField]
    private Player_FloorCheck _floorCheck;

    // Private Variables
    private InputAction _move;
    private InputAction _jump;

    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        // Fetch the input action map named "Player"
        InputActionMap map = InputSystem.actions.FindActionMap("Player");

        // Fetch the actions named "Move" and "Jump"
        _move = map.FindAction("Move");
        _jump = map.FindAction("Jump");
    }

    // Update is called once per frame
    void Update()
    {
        // Poll Move and Jump actions
        Vector2 moveAction = _move.ReadValue<Vector2>();
        bool jumpAction = _jump.WasPressedThisFrame();

        // Do jump
        if (jumpAction && _floorCheck.Floored)
        {
            // Add force to rigidbody
            _rigidBody.AddForceY(500);
        }

        // Do movement
        gameObject.transform.position = new Vector3
            (
                gameObject.transform.position.x + 10 * moveAction.x * Time.deltaTime,
                gameObject.transform.position.y,
                gameObject.transform.position.z
            );
    }
}
