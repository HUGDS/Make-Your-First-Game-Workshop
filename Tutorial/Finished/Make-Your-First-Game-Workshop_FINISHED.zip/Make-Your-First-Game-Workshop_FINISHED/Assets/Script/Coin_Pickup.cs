using UnityEngine;

public class Coin_Pickup : MonoBehaviour
{
    // Editor Variables
    [SerializeField]
    private SpriteRenderer _renderer;
    [SerializeField]
    private AudioSource _playback;

    // Private Variables
    private bool _collected = false;

    // Called when something collides with the coin
    private void OnTriggerEnter2D(Collider2D collision)
    {
        // Ensure that the coin cannot be collected multiple times
        if (_collected) return;

        // Tell audio source to play sound
        _playback.Play();

        // Hide the coin
        _renderer.color = Color.clear;

        // Set the coin to be collected
        _collected = true;
    }
}
